import logo from './logo.svg';
import './stylesheets/css/style.css';
import Layout from './modules/layout/layout'

function App() {
  return (
    <div className="App">
      <Layout />
    </div>
  );
}

export default App;
